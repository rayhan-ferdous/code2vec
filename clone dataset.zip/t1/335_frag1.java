        if ("boolean".equals(rType)) {

            return "Boolean";

        }

        if ("byte".equals(rType)) {

            return "Byte";

        }

        if ("char".equals(rType)) {

            return "Char";

        }

        if ("short".equals(rType)) {

            return "Short";

        }

        if ("int".equals(rType)) {

            return "Integer";

        }

        if ("long".equals(rType)) {

            return "Long";

        }

        if ("float".equals(rType)) {
