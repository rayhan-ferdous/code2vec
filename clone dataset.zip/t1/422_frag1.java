    public void run() {

        try {

            generateDiffs();

            workingDialog.hide();

        } catch (UserCancel uc) {

        }

    }
