    public String[] getSortedColumns() {

        if (fSortedColumn != null) {

            return new String[] { fSortedColumn };

        } else {

            return null;

        }

    }
