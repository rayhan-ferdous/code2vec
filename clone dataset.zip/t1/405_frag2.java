        final StringBuilder sb = new StringBuilder();

        sb.append(raw.substring(0, 8));

        sb.append("-");

        sb.append(raw.substring(8, 12));

        sb.append("-");

        sb.append(raw.substring(12, 16));

        sb.append("-");

        sb.append(raw.substring(16, 20));

        sb.append("-");

        sb.append(raw.substring(20));

        return sb.toString();

    }
