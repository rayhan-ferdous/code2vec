            if ("hasindexes".equals(pColumn)) return new Boolean(fTotal.getHasindexes());

            if ("hasrules".equals(pColumn)) return new Boolean(fTotal.getHasrules());

            if ("hastriggers".equals(pColumn)) return new Boolean(fTotal.getHastriggers());
