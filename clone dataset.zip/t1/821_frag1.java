        return 0;

    }



    public void reallocateIndexes() {

        int rowCount = model.getRowCount();

        indexes = new int[rowCount];

        for (int row = 0; row < rowCount; row++) {

            indexes[row] = row;

        }

    }



    public void tableChanged(TableModelEvent e) {

        reallocateIndexes();

        super.tableChanged(e);

    }



    public void checkModel() {

        if (indexes.length != model.getRowCount()) {

            System.err.println("Sorter not informed of a change in model.");

        }

    }



    public void sort(Object sender) {

        checkModel();

        compares = 0;

        shuttlesort((int[]) indexes.clone(), indexes, 0, indexes.length);

    }



    public void n2sort() {

        for (int i = 0; i < getRowCount(); i++) {

            for (int j = i + 1; j < getRowCount(); j++) {

                if (compare(indexes[i], indexes[j]) == -1) {

                    swap(i, j);
