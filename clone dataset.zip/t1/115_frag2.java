            if ("beneficiary".equals(pColumn)) return fTotal.getBeneficiary();

            if ("message4x35".equals(pColumn)) return fTotal.getMessage4x35();

            if ("orderer".equals(pColumn)) return fTotal.getOrderer();
