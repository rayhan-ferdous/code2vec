    MemoryUsage() {

        nativeSharedPages = -1;

        javaSharedPages = -1;

        otherSharedPages = -1;

        nativePrivatePages = -1;

        javaPrivatePages = -1;

        otherPrivatePages = -1;

        allocCount = -1;

        allocSize = -1;

        freedCount = -1;

        freedSize = -1;

        nativeHeapSize = -1;

    }
