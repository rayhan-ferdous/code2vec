    public static final void main(String[] args) {

        if (args.length < 3) {

            usage("Not enough arguments.");

        } else {

            String flag = args[0];

            String infile = args[1];

            String outfile = args[2];

            if (flag.equals("-e")) {

                Base64.encodeFileToFile(infile, outfile);

            } else if (flag.equals("-d")) {

                Base64.decodeFileToFile(infile, outfile);

            } else {

                usage("Unknown flag: " + flag);

            }

        }

    }
