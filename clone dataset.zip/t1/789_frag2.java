        if ("id".equals(pColumn)) return new Long(vo.getId());

        if ("type".equals(pColumn)) return vo.getType();

        if ("ta".equals(pColumn)) return vo.getTa();
